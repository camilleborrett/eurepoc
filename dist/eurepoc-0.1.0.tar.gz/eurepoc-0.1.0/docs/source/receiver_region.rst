receiver_region
===============

The following regions can be queried in the database, **only use the abbreviations in CAPS**.
Leaving the filter to its default value (None) will return all regions.

* **AFRICA**
* **ASIA**
* **BALKANS**
* **CENTAM** - *Central America*
* **CENTAS** - *Central Asia*
* **CSTO** - *Collective Security Treaty Organization)*
* **EASIA** - *East Asia*
* **EASTEU** - *Eastern Europe*
* **EU**
* **EUROPE**
* **GULFC** - *Gulf Cooperation Council*
* **MEA** - *Middle East and Africa*
* **MENA** - *Middle East and North Africa*
* **NAF** - *North Africa*
* **NATO**
* **NEA** - *Northeast Asia*
* **NORTHAM** - *North America)*
* **NORTHEU** *(Northern Europe*
* **OC** - *Oceania*
* **SASIA** - *South Asia*
* **SCO** - *Shanghai Cooperation Organization*
* **SCS** - *South China Sea*
* **SEA** - *South East Asia*
* **SOUTHAM** - *South America*
* **SSA** - *Sub-Saharan Africa*
* **WBALKANS** - *Western Balkans*
* **WESTEU** - *Western Europe*
