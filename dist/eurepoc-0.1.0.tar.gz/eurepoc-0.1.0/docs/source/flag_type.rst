flag_type
=========